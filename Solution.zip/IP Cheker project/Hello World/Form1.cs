﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;

namespace Hello_World
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
                // Coded by Ali Javadi

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            // for Get Ip From Ipify
            WebClient webClient = new WebClient();
            string IP = webClient.DownloadString("https://api.ipify.org");
            String StaticIP = "5.160.28.90";
            if(IP == StaticIP)
            {
                Vpn_Label.ForeColor = System.Drawing.Color.Red;
                Vpn_Label.Text = string.Format("You Not Use VPN");
            }
            else
            {
                Vpn_Label.ForeColor = System.Drawing.Color.Green;
                Vpn_Label.Text = string.Format("You Use VPN");
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            WebClient webClient = new WebClient();
            string IP = webClient.DownloadString("https://api.ipify.org");
            label1.Text = string.Format("Your Ip is : {0}", IP);
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void LinkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }
}
